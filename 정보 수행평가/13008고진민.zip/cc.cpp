//#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
char A[101]={};
char B[101]={};
int n,k,i,j;
int main(){
	freopen("input.txt","r",stdin);
	freopen("output.txt","w",stdout);

	scanf("%s",&A);
	scanf("%s",&B);
	printf("4");
	
}